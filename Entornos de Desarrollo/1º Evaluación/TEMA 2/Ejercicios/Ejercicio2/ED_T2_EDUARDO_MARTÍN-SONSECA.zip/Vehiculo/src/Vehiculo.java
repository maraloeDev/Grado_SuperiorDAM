/**************************************************
 * Copyright (c) EDUARDO MARTÍN-SONSECA (maraloed)
 **************************************************/

public class Vehiculo {

    //Atributos

    String numero_Matricula;
    String marca;
    String modelo;

    //Constructor

    public Vehiculo(String numero_Matricula, String marca, String modelo) {
        this.numero_Matricula = numero_Matricula;
        this.marca = marca;
        this.modelo = modelo;
    }
    // Getter and Setter


    public String getNumero_Matricula() {
        return numero_Matricula;
    }

    public void setNumero_Matricula(String numero_Matricula) {
        this.numero_Matricula = numero_Matricula;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    //toString


    @Override
    public String toString() {
        return "Vehiculo{" +
                "numero_Matricula='" + numero_Matricula + '\'' +
                ", marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                '}';
    }
}
